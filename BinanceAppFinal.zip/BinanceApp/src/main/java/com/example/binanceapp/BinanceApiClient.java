package com.example.binanceapp;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class BinanceApiClient {

    private static final String API_URL = "https://api4.binance.com/api/v3/ticker/24hr";


    public BinanceTickerData[] fetchDataFromApi() {
        BinanceTickerData[] tickerDataArray = new BinanceTickerData[0];
        try {
            // Create URL object
            URL url = new URL(API_URL);

            // Create HttpURLConnection
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set request method
            connection.setRequestMethod("GET");

            // Get the response code
            int responseCode = connection.getResponseCode();
            System.out.println("Response Code: " + responseCode);

            // Read the response
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // Parse JSON response using Gson
            Gson gson = new Gson();
            // Assuming you have a class named BinanceTickerData to represent the data structure
            tickerDataArray = gson.fromJson(response.toString(), BinanceTickerData[].class);

            // Print the parsed data
            for (BinanceTickerData tickerData : tickerDataArray) {
                System.out.println(tickerData.toString());
            }

            // Disconnect the connection
            connection.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //return null;
        return tickerDataArray;
    }
}
