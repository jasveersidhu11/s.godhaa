package com.example.binanceapp;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class BinanceController {
    @FXML
    private Label welcomeText;
    @FXML
    private VBox dataContainer; // Reference to the VBox in SecondScene.fxml

    private BinanceApiClient binanceApiClient = new BinanceApiClient();

    @FXML
    protected void onButtonClick() {
        // Fetch data from the API
        BinanceTickerData[] tickerDataArray = binanceApiClient.fetchDataFromApi();

        // Check if data is fetched successfully
        if (tickerDataArray != null && tickerDataArray.length > 0) {
            // Update the welcomeText label with the fetched data
            welcomeText.setText("Symbol: " + tickerDataArray[0].getSymbol() +
                    ", Price Change: " + tickerDataArray[0].getPriceChange() +
                    ", Price Change Percent: " + tickerDataArray[0].getPriceChangePercent());
            onSecondSceneButtonClick(tickerDataArray);

        } else {
            // Handle the case where data fetching fails
            welcomeText.setText("Failed to fetch data from API");
        }
    }

    @FXML
    protected void onSecondSceneButtonClick(BinanceTickerData[] tickerDataArray) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(BinanceApplication.class.getResource("DataDisplayView.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            DataController dataController = fxmlLoader.getController();
            dataController.initialize(tickerDataArray);

            Stage stage = new Stage();

            stage.setTitle("Data Viewer");
            stage.getIcons().add(new Image(Objects.requireNonNull(getClass().getResourceAsStream("OIP.png"))));
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




}
