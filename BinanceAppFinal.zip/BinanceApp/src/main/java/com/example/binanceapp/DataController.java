package com.example.binanceapp;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import java.util.List;

/**
 * Controller class for the Memes View.
 */
public class DataController {

    @FXML
    private Label secondSceneLabel;
    @FXML
    private VBox dataContainer; // Reference to the VBox in SecondScene.fxml
    public void initialize(BinanceTickerData[] tickerDataArray) {
        populateSecondScene(tickerDataArray);

    }

    // Method to populate the second scene with fetched data
    private void populateSecondScene(BinanceTickerData[] tickerDataArray) {

        if (tickerDataArray != null && tickerDataArray.length > 0) {
            // Clear existing content
            dataContainer.getChildren().clear();
            StringBuilder dataText = new StringBuilder();
            // Add fetched data to the VBox
            for (BinanceTickerData data : tickerDataArray) {
                /*Label label = new Label("Symbol: " + data.getSymbol() +
                        ", Price Change: " + data.getPriceChange() +
                        ", Price Change Percent: " + data.getPriceChangePercent());*/
                //dataContainer.getChildren().add(label);
                dataText.append("Symbol: ").append(data.getSymbol()).append(", Price Change: ").append(data.getPriceChange()).append(", Price Change Percent: ").append(data.getPriceChangePercent()).append("\n");

            }
            secondSceneLabel.setText(dataText.toString());
        } else {
            // Handle the case where data fetching fails
            Label errorLabel = new Label("Failed to fetch data for second scene");
            dataContainer.getChildren().add(errorLabel);
        }
    }
}
